#include "ConnectionManager.h"
#include <iostream>
#include <chrono>
#include <devguid.h>
#include <algorithm>

ConnectionManager::ConnectionManager() : mIsRunning(false), mCurrentDeviceHandler(nullptr) {}

ConnectionManager::~ConnectionManager() {
    stop();
}

void ConnectionManager::start() {
    mIsRunning = true;
    mMonitorThreadLoop = std::thread(&ConnectionManager::monitorLoop, this);
    const std::vector<std::string> availablePorts = getAvailablePorts();
}

void ConnectionManager::stop() {
    mIsRunning = false;
    if (mMonitorThreadLoop.joinable()) {
        mMonitorThreadLoop.join();
    }
}

bool ConnectionManager::updateDeviceInformation(const std::string &portName) {
    std::cout << "New device found on " << portName << ". Adding to manager." << std::endl;

    // Create a shared pointer for the SerialPortHandler
    std::shared_ptr<SerialPortHandler> handler = std::make_shared<SerialPortHandler>(portName);

    if (!handler->connect()) {
        std::cerr << "Failed to connect to device on " << portName << std::endl;
        return false; // Connection failed, do not add.
    }

    std::string deviceName = handler->sendCommandAndWaitForResponse("GET_DEVICE_NAME\n");
    if (!deviceName.empty() && (deviceName == mCurrentDeviceID)) {
        std::lock_guard<std::mutex> lock(mHandlerMutex);
        mCurrentDeviceHandler = handler; // Assign the shared pointer to the current device handler
        std::cout << "Device on " << portName << " identified as: " << deviceName << std::endl;
    } else {
        std::cerr << "Could not get device name from " << portName << std::endl;
        handler->disconnect();
        return false;
    }
    return true;
}

bool ConnectionManager::sellectCurrentDevice(const std::string &deviceID) {

    static const std::vector<std::string> validDeviceIDs = {
        "BOARD_A",
        "BOARD_B",
        "BOARD_C",
        "BOARD_D",
    };
    if ((deviceID == mCurrentDeviceID) ||
        (std::find(validDeviceIDs.begin(), validDeviceIDs.end(), deviceID) == validDeviceIDs.end())) {
        return false;
    }

    mCurrentDeviceID = deviceID;
    std::cout << "Selected device: " << mCurrentDeviceID << std::endl;

    std::lock_guard<std::mutex> lock(mHandlerMutex);
    if (mCurrentDeviceHandler != nullptr) {

        std::string currentPortId = mCurrentDeviceHandler->sendCommandAndWaitForResponse("GET_DEVICE_ID\n");
        if (currentPortId != mCurrentDeviceID) {
            mCurrentDeviceHandler->disconnect();
            mCurrentDeviceHandler = nullptr;
            return true;
        }
        std::cout << "Current device ID: " << currentPortId << std::endl;
    }
    return true;
}

bool ConnectionManager::isArduinoPort(const std::string &portName) {
    bool isArduino = false;
    if ((portName.find("Arduino") != std::string::npos) ||
        (portName.find("CH340") != std::string::npos) ||
        (portName.find("CP210") != std::string::npos)) {
        isArduino = true;
    }
    return isArduino;
}

std::string ConnectionManager::getDevicePort(SP_DEVINFO_DATA &devInfoData, HDEVINFO& hDevInfo) {
    std::string portNameStr;
    HKEY hDeviceRegistryKey = SetupDiOpenDevRegKey(hDevInfo, &devInfoData, DICS_FLAG_GLOBAL, 0, DIREG_DEV, KEY_READ);

    if (hDeviceRegistryKey != INVALID_HANDLE_VALUE) {
        char portName[256] = {0};
        DWORD dataSize = sizeof(portName);
        if (RegQueryValueExA(
            hDeviceRegistryKey,
            "PortName",
            NULL,
            NULL,
            (LPBYTE)portName,
            &dataSize) == ERROR_SUCCESS) {

            portNameStr = std::string(portName);
        }
        RegCloseKey(hDeviceRegistryKey);
    }
    return portNameStr;
}

std::vector<std::string> ConnectionManager::getAvailablePorts() {
    std::vector<std::string> portNames;
    HDEVINFO hDevInfo = SetupDiGetClassDevsA(&GUID_DEVCLASS_PORTS, 0, 0, DIGCF_PRESENT);
    if (hDevInfo == INVALID_HANDLE_VALUE) {
        return portNames;
    }

    SP_DEVINFO_DATA devInfoData;
    devInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    for (DWORD i = 0; SetupDiEnumDeviceInfo(hDevInfo, i, &devInfoData); i++) {

        bool isArduino = false;
        char friendlyName[256] = {0};
        if (SetupDiGetDeviceRegistryPropertyA(
            hDevInfo,
            &devInfoData,
            SPDRP_FRIENDLYNAME, NULL,
            (PBYTE)friendlyName,
            sizeof(friendlyName),
            NULL)) {

            std::string nameStr(friendlyName);
            isArduino = isArduinoPort(nameStr);
        }
        if (isArduino == false) {
            continue;
        }
        std::string portName = getDevicePort(devInfoData, hDevInfo);
        if (portName.empty() == false) {
            portNames.push_back(portName);
        }
    }
    SetupDiDestroyDeviceInfoList(hDevInfo);
    return portNames;
}

std::string ConnectionManager::sendCommandToArduino(const std::string &command) const {
    std::lock_guard<std::mutex> lock(mHandlerMutex);
    std::string response;
    if ((mCurrentDeviceHandler != nullptr) && (mCurrentDeviceHandler->isConnected())) {
        response = mCurrentDeviceHandler->sendCommandAndWaitForResponse(command);
    } else {
        std::cerr << "No connected Arduino device to send command to." << std::endl;
    }
    return response;
}

void ConnectionManager::monitorLoop() {

    while (mIsRunning == true) {

        const std::vector<std::string> availablePorts = getAvailablePorts();
        std::string currentPort = "INVALID_PORT";

        if (mCurrentDeviceHandler != nullptr) {
            currentPort = mCurrentDeviceHandler->getPortName();

        } else if (mCurrentDeviceHandler == nullptr) {

            for (const auto &port : availablePorts) {
                updateDeviceInformation(port);
            }
        }

        bool isConnectionAvailable = false;
        if (currentPort == "INVALID_PORT") {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }
        for (const auto &port : availablePorts) {
            if (currentPort == port) {
                isConnectionAvailable = true;
            }
        }
        if (isConnectionAvailable == false) {
            mCurrentDeviceHandler->disconnect();
            mCurrentDeviceHandler = nullptr;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
}