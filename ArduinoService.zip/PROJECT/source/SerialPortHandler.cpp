#include "SerialPortHandler.h"
#include <iostream>
#include <windows.h>
#include <chrono> // Ensure this is included for sleep_for

// Assuming mHandeComm is a member of SerialPortHandler

SerialPortHandler::SerialPortHandler(const std::string &portName)
    : mPortName(portName), mIsConnected(false), mHandeComm(INVALID_HANDLE_VALUE) {}

SerialPortHandler::~SerialPortHandler() {
    std::cout << "Destructor called for SerialPortHandler on port: " << mPortName << std::endl;
    disconnect();
}

bool SerialPortHandler::connect()
{
    if (mIsConnected) {
        return true;
    }

    std::cout << "Attempting to connect to " << mPortName << std::endl;
    std::string fullPortName = "\\\\.\\" + mPortName;

    // --- 1. REMOVE FILE_FLAG_OVERLAPPED (Remains fixed for synchronous mode) ---
    mHandeComm = CreateFileA(fullPortName.c_str(),
                          GENERIC_READ | GENERIC_WRITE,
                          0,
                          NULL,
                          OPEN_EXISTING,
                          0,
                          NULL);

    if (mHandeComm == INVALID_HANDLE_VALUE)
    {
        std::cerr << "Error opening serial port " << mPortName << ". Error: " << GetLastError() << std::endl;
        return false;
    }

    // Clear any junk data lingering in the buffer from the connection attempt
    PurgeComm(mHandeComm, PURGE_RXCLEAR | PURGE_TXCLEAR);

    DCB dcbSerialParams = {0};
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
    if (!GetCommState(mHandeComm, &dcbSerialParams)) {
        std::cerr << "Error getting device state. Error: " << GetLastError() << std::endl;
        CloseHandle(mHandeComm); mHandeComm = INVALID_HANDLE_VALUE; return false;
    }

    dcbSerialParams.BaudRate = CBR_115200; // Assuming 115200 from your ESP32
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;
    dcbSerialParams.fDtrControl = DTR_CONTROL_ENABLE;

    // Disable flow control
    dcbSerialParams.fOutxCtsFlow = FALSE;
    dcbSerialParams.fRtsControl = RTS_CONTROL_ENABLE;

    if (!SetCommState(mHandeComm, &dcbSerialParams)) {
        std::cerr << "Error setting device parameters. Error: " << GetLastError() << std::endl;
        CloseHandle(mHandeComm); mHandeComm = INVALID_HANDLE_VALUE; return false;
    }

    // --- 2. TIGHTER TIMEOUTS (Remains fixed at 50ms) ---
    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = MAXDWORD;
    timeouts.ReadTotalTimeoutConstant = 50;
    timeouts.ReadTotalTimeoutMultiplier = 0;

    timeouts.WriteTotalTimeoutConstant = 50;
    timeouts.WriteTotalTimeoutMultiplier = 0;

    if (!SetCommTimeouts(mHandeComm, &timeouts)) {
        std::cerr << "Error setting timeouts. Error: " << GetLastError() << std::endl;
    }

    mIsConnected = true;
    std::cout << "Successfully connected to " << mPortName << std::endl;

    // --- CRITICAL FIX: BOOT DELAY ---
    // The device resets when the port is opened. We MUST wait for the firmware
    // to boot (usually 1.5s - 2s for ESP32/Arduino).
    // The previous sleep(1000) was in the wrong place and caused the initial failure.
    std::cout << "Waiting 2 seconds for device boot and Serial initialization..." << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));

    // Clear the buffer again after the boot message ("Arduino Ready: Awaiting...")
    // that the Arduino sketch sends, otherwise the next read will return this junk.
    PurgeComm(mHandeComm, PURGE_RXCLEAR);

    return true;
}

// ... rest of SerialPortHandler.cpp remains unchanged ...

const std::string &SerialPortHandler::getPortName() const
{
    return mPortName;
}

void SerialPortHandler::disconnect() {
    mIsConnected = false;
    if (mIsCommThread.joinable()) {
        mIsCommThread.join();
    }
    CloseHandle(mHandeComm);
    mHandeComm = INVALID_HANDLE_VALUE;
    std::cout << "Disconnected from " << mPortName << std::endl;
}

bool SerialPortHandler::isConnected() const
{
    return mIsConnected.load();
}

// Simplified for immediate synchronous command/response
std::string SerialPortHandler::sendCommandAndWaitForResponse(const std::string &command) {
    if (!isConnected() || mHandeComm == INVALID_HANDLE_VALUE) {
        return "";
    }
    // Add the required newline delimiter for the Arduino sketch
    std::string fullCommand = command + "\n";
    DWORD bytesWritten = 0;

    if (!WriteFile(mHandeComm, fullCommand.c_str(), fullCommand.length(), &bytesWritten, NULL)) {
        std::cerr << "WriteFile failed. Error: " << GetLastError() << std::endl;
        return "";
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(5));

    // Read the response
    return receiveData();
}

std::string SerialPortHandler::receiveData()
{
    std::string response;
    char buffer[256];
    DWORD bytesRead = 0;

    if (!isConnected() || mHandeComm == INVALID_HANDLE_VALUE) {
        return "";
    }

    while (true)
    {
        // Use synchronous ReadFile (NULL for OVERLAPPED)
        if (!ReadFile(mHandeComm, buffer, sizeof(buffer) - 1, &bytesRead, NULL))
        {
            DWORD error = GetLastError();
            if (error != ERROR_SUCCESS) {
                if (error != ERROR_SUCCESS && error != ERROR_IO_PENDING) {
                    std::cerr << "ReadFile error. Error: " << error << std::endl;
                }
                break;
            }
        }

        if (bytesRead > 0)
        {
            buffer[bytesRead] = '\0';

            for (DWORD i = 0; i < bytesRead; i++)
            {
                char c = buffer[i];

                if (c == '\n') {
                    return response;
                }

                if (c != '\r') {
                    response += c;
                }
            }
        }
        else
        {
            break;
        }
    }
    return response;
}

void SerialPortHandler::communicationLoop() {
    // Implementation for the thread loop (for background discovery/data queuing)
}