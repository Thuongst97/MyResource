#ifndef ARDUINO_MANAGER_SERVICE_H
#define ARDUINO_MANAGER_SERVICE_H

#include <string>
#include <vector>
#include <cstdint>
#include "ConnectionManager.h"
#include "NetworkInterface.h"


class ArduinoManagerService {
 public:
    ArduinoManagerService();
    ~ArduinoManagerService();

    bool startService();
    bool stopService();

 private:
    const int32_t SERVICE_PORT = 12345;
    ConnectionManager mConnectionManager;
    NetworkInterface  mNetworkInterface;
};

#endif // ARDUINO_MANAGER_SERVICE_H