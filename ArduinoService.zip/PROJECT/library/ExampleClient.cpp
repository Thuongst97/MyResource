// ExampleClient.cpp
#include "ArduinoClient.h"
#include <iostream>
#include <vector>
#include <string>
#include <chrono>
#include <thread>
#include <cstring>

int main(int argc, char *argv[])
{

    char buffer[1024];
    if (argc > 1)
    {
        std::cout << "Command count: " << argc << std::endl;
        std::cout << "Using command line argument: " << argv[1] << std::endl;
        std::strncpy(buffer, argv[1], sizeof(buffer) - 1);
        buffer[sizeof(buffer) - 1] = '\0';
    }
    else
    {
        std::strcpy(buffer, "DefaultMessage");
    }

        // Example: Send a message
    while (true) {
        ArduinoClient client;
        std::string host = "127.0.0.1"; // Change to your Arduino service IP
        int port = 12345;               // Change to your Arduino service port

        if (!client.connect(host, port))
        {
            std::cerr << "Failed to connect to Arduino Service." << std::endl;
            return 1;
        }
        std::cout << "Connected to Arduino Service." << std::endl;

        std::string message = std::string(buffer);
        auto startTime = std::chrono::high_resolution_clock::now();
        std::vector<uint8_t> data(message.begin(), message.end());
        if (client.send(data))
        {
            time_t now = time(nullptr);
            std::cout << "Sent: " << message << " at " << std::ctime(&now);
        }
        else
        {
            std::cerr << "Send failed." << std::endl;
        }

        // Example: Receive a response
        std::vector<uint8_t> response = client.receive();
        if (!response.empty())
        {
            std::string respStr(response.begin(), response.end());
            std::cout << "Received: " << respStr << std::endl;

            auto endTime = std::chrono::high_resolution_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);

            std::cout << "Response duration: " << elapsed.count() << " milliseconds." << std::endl;
        }
        else
        {
            std::cerr << "No response or connection closed." << std::endl;
        }
        std::cout << "Disconnected." << std::endl;
        client.disconnect();
        std::this_thread::sleep_for(std::chrono::seconds(1)); // Add a delay before the next iteration
    }

    return 0;
}
