
#include <winsock2.h>
#include <iostream>
#include <thread>
#include <chrono>
#include <string>
#include "ConnectionManager.h"
#include "NetworkInterface.h"
#pragma comment(lib, "ws2_32.lib")

NetworkInterface::NetworkInterface(int port, ConnectionManager *connMgr)
    : mExposedPort(port), mIsRunning(false), mConnectionMgr(connMgr) {}
NetworkInterface::~NetworkInterface() {
    stop();
}

void NetworkInterface::start() {
    mIsRunning = true;
    mServerThreadLoop = std::thread(&NetworkInterface::serverLoop, this);
}

void NetworkInterface::stop() {
    mIsRunning = false;
    if (mServerThreadLoop.joinable()) {
        mServerThreadLoop.join();
    }
}

void NetworkInterface::sendCommand(const std::string &cmd) {
    // Placeholder: send command to client
    std::cout << "Sending command: " << cmd << std::endl;
}

void NetworkInterface::serverLoop() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
    int server_fd;
    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        std::cerr << "Socket creation failed\n";
        return;
    }

    sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(mExposedPort);

    // Bind socket
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        std::cerr << "Bind failed\n";
        closesocket(server_fd);
        WSACleanup();
        return;
    }

    // Listen
    if (listen(server_fd, 3) < 0) {
        std::cerr << "Listen failed\n";
        closesocket(server_fd);
        WSACleanup();
        return;
    }

    std::cout << "Server running on port " << mExposedPort << std::endl;

    while (mIsRunning) {

        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(server_fd, &readfds);

        timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        int activity = select(server_fd + 1, &readfds, NULL, NULL, &timeout);

        if (activity > 0 && FD_ISSET(server_fd, &readfds)) {
            sockaddr_in client_addr;
            int addrlen = sizeof(client_addr);
            int client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addrlen);
            if (client_fd >= 0) {
                // Handle the client connection in a separate function
                handleClient(client_fd);
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    closesocket(server_fd);
    WSACleanup();
}

void NetworkInterface::handleClient(int client_fd) {
    char buffer[1024] = {0};
    int valread = recv(client_fd, buffer, sizeof(buffer), 0);
    if (valread > 0) {
        std::string request(buffer, valread);
        std::cout << std::endl;
        std::cout << "Processing request: " << request << std::endl;
        processAndRespond(request, client_fd);
    }
    closesocket(client_fd);
}

void NetworkInterface::processAndRespond(const std::string &request, int client_fd) {
    std::string response;

    if (mConnectionMgr == nullptr) {
        std::string errorMsg = "ERROR: Connection Manager not available.";
        std::cout << errorMsg << std::endl;
        response = errorMsg;
    } else if (request.find("SELECT_BOARD_A") == 0) {
        const std::string deviceID = "BOARD_A";
        bool ret = mConnectionMgr->sellectCurrentDevice(deviceID);
        response = "Device selection processed, ret: " + std::to_string(ret) + "\n";

    } else if (request.find("SELECT_BOARD_B") == 0) {
        const std::string deviceID = "BOARD_B";
        bool ret = mConnectionMgr->sellectCurrentDevice(deviceID);
        response = "Device selection processed, ret: " + std::to_string(ret) + "\n";

    } else if (mConnectionMgr != nullptr) {
        response = mConnectionMgr->sendCommandToArduino(request);
    }
    if (response.empty() == false) {
        std::cout << "Response received from Arduino: " << response;
        send(client_fd, response.c_str(), response.length(), 0);

    }  else {
        std::cout << "No response from Arduino." << std::endl;
    }
}
