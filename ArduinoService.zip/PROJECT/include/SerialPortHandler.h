#ifndef SERIAL_PORT_HANDLER_H
#define SERIAL_PORT_HANDLER_H

#include <string>
#include <thread>
#include <atomic>
#include <mutex>
#include <list>
#include <windows.h>

class SerialPortHandler
{
public:
    SerialPortHandler(const std::string &portName);
    ~SerialPortHandler();

    bool connect();
    void disconnect();
    bool isConnected() const;
    std::string sendCommandAndWaitForResponse(const std::string &command);
    std::string receiveData();
    const std::string &getPortName() const;

private:
    void communicationLoop();
    std::string mPortName;
    std::atomic<bool> mIsConnected;
    HANDLE mHandeComm;
    std::thread mIsCommThread;
};

#endif // SERIAL_PORT_HANDLER_H