
#include "ArduinoClient.h"
// Only for WIN64
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#include <cstring>
#include <cstdint>
#include <ws2tcpip.h>
#include <cstdint>

ArduinoClient::ArduinoClient() : sockfd(-1), connected(false) {
    initSocket();
}

ArduinoClient::~ArduinoClient() {
    disconnect();
    cleanupSocket();
}

void ArduinoClient::initSocket() {
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
}

void ArduinoClient::cleanupSocket() {
    WSACleanup();
}

bool ArduinoClient::connect(const std::string &host, int port) {
    disconnect();
    sockfd = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd < 0)
        return false;

    sockaddr_in serverAddr;
    std::memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    if (::inet_pton(AF_INET, host.c_str(), &serverAddr.sin_addr) <= 0) {
        disconnect();
        return false;
    }
    if (::connect(sockfd, (sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        disconnect();
        return false;
    }
    connected = true;
    return true;
}

bool ArduinoClient::send(const std::vector<uint8_t> &data) {
    if (!connected || sockfd < 0)
        return false;
    int sent = ::send(sockfd, reinterpret_cast<const char *>(data.data()), (int)data.size(), 0);
    return sent == (int)data.size();
}

std::vector<uint8_t> ArduinoClient::receive(size_t maxLength) {
    std::vector<uint8_t> buffer(maxLength);
    if (!connected || sockfd < 0)
        return {};
    int received = ::recv(sockfd, reinterpret_cast<char *>(buffer.data()), (int)maxLength, 0);
    if (received <= 0) {
        disconnect();
        return {};
    }
    buffer.resize(received);
    return buffer;
}

void ArduinoClient::disconnect() {
    if (sockfd >= 0) {
        ::closesocket(sockfd);
        sockfd = -1;
    }
    connected = false;
}

bool ArduinoClient::isConnected() const {
    return connected;
}
