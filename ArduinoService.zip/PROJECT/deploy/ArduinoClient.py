import socket
import sys
import time

def main():
    """
    A Python client to connect to the Arduino Gateway Service,
    send a command, and print the response. This script mimics
    the behavior of the C++ ExampleClient.
    """
    host = "127.0.0.1"  # The server's hostname or IP address
    port = 12345        # The port used by the server

    # Determine the message to send from command-line arguments,
    # defaulting to "DefaultMessage" if none is provided.
    if len(sys.argv) > 1:
        message = sys.argv[1]
        print(f"Using command line argument: {message}")
    else:
        message = "SELECT_BOARD_A\n"
        print(f"Using default message: {message}")

    # Main loop to continuously send messages every second
    while True:
        try:
            # The 'with' statement ensures the socket is automatically closed
            # after the block is executed, even if errors occur.
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((host, port))
                print("Connected to Arduino Service.")

                start_time = time.time()

                # Send the message, encoded as bytes
                print(f"Sent: {message}")
                s.sendall(message.encode('utf-8'))

                # Wait for and receive the response from the server
                response_data = s.recv(1024)
                end_time = time.time()

                response_str = response_data.decode('utf-8').strip()
                print(f"Received: {response_str}")

                # Calculate duration in seconds and convert to milliseconds
                duration_ms = (end_time - start_time) * 1000
                print(f"Response duration: {duration_ms:.2f} milliseconds.\n")

        except ConnectionRefusedError:
            print("Connection refused. Is the Arduino Gateway Service running?")
        except Exception as e:
            print(f"An error occurred: {e}")

        # Wait for 1 second before the next iteration
        time.sleep(1)

if __name__ == "__main__":
    main()