#ifndef ARDUINOCLIENT_H
#define ARDUINOCLIENT_H

// ArduinoClient.h
#include <string>
#include <vector>
#include <cstdint>

class ArduinoClient
{
public:
    ArduinoClient();
    ~ArduinoClient();

    bool connect(const std::string &host, int port);
    bool send(const std::vector<uint8_t> &data);
    std::vector<uint8_t> receive(size_t maxLength = 1024);
    void disconnect();
    bool isConnected() const;

private:
    int sockfd;
    bool connected;
    void initSocket();
    void cleanupSocket();
};

#endif // ARDUINOCLIENT_H
