# Arduino Gateway Windows Service

This project is a Windows service written in C++ to manage connections with Arduino devices. It auto-detects available Arduino devices (COM ports), auto-connects, and manages connections as described in the architecture diagram.

## Project Structure

-   `source/` - C++ source files
-   `include/` - Header files
-   `library/` - External libraries
-   `build/` - Build output
-   `CMakeLists.txt` - CMake build configuration

## Features

-   Auto-detect COM ports
-   Monitor device availability
-   Handle reconnect logic
-   TCP/IP socket interface for Windows applications

## Build Instructions

1. Install CMake and a C++ compiler (MSVC recommended).
2. Run CMake to generate build files:
    ```
    cmake -G "MinGW Makefiles" ..
    mingw32-make
    ```
3. Run the service executable from the `build` directory.

## Next Steps

-   Implement service logic in `source/` and `include/` folders.
-   Add external libraries to `library/` if needed.
