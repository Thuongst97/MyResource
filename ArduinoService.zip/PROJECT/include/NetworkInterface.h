#ifndef NETWORKINTERFACE_H
#define NETWORKINTERFACE_H

#include <string>
#include <atomic>
#include <thread>
#include "ConnectionManager.h"

class NetworkInterface
{
public:
    NetworkInterface(int port, ConnectionManager *connMgr);
    ~NetworkInterface();
    void start();
    void stop();
    void sendCommand(const std::string &cmd);

private:
    int32_t mExposedPort;
    std::thread mServerThreadLoop;
    std::atomic<bool> mIsRunning;
    ConnectionManager *mConnectionMgr;
    void serverLoop();
    void handleClient(int client_fd);
    void processAndRespond(const std::string &request, int client_fd);
};

#endif // NETWORKINTERFACE_H