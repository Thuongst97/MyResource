#ifndef CONNECTION_MANAGER_H
#define CONNECTION_MANAGER_H

#include <string>
#include <vector>
#include <list>
#include <memory>
#include <thread>
#include <mutex>
#include <atomic>

// Required for SP_DEVINFO_DATA and HDEVINFO
#include <windows.h>
#include <setupapi.h>
#include "SerialPortHandler.h"


class ConnectionManager {
public:
    ConnectionManager();
    ~ConnectionManager();

    void start();
    void stop();
    bool sellectCurrentDevice(const std::string &deviceID);
    std::string sendCommandToArduino(const std::string &command) const;

private:
    void monitorLoop();

    bool updateDeviceInformation(const std::string &portName);
    bool isArduinoPort(const std::string &portName);

    std::vector<std::string> getAvailablePorts();
    std::string getDevicePort(SP_DEVINFO_DATA &devInfoData, HDEVINFO& hDevInfo);

    std::string mCurrentDeviceID = "BOARD_D";
    std::atomic<bool> mIsRunning;
    std::thread mMonitorThreadLoop;
    mutable std::mutex mHandlerMutex;
    std::shared_ptr<SerialPortHandler> mCurrentDeviceHandler;
};

#endif // CONNECTION_MANAGER_H