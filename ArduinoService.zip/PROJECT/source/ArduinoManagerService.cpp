#include "NetworkInterface.h"
#include "ConnectionManager.h"
#include <iostream>
#include "ArduinoManagerService.h"

ArduinoManagerService::ArduinoManagerService(): mConnectionManager(),
    mNetworkInterface(SERVICE_PORT, &mConnectionManager) {}

ArduinoManagerService::~ArduinoManagerService() {
    stopService();
}


bool ArduinoManagerService::startService() {
    mNetworkInterface.start();
    mConnectionManager.start();
    return true;
}

bool ArduinoManagerService::stopService() {
    mNetworkInterface.stop();
    mConnectionManager.stop();
    return true;
}


int main()
{
    ArduinoManagerService service;
    service.startService();

    std::cout << "Starting Arduino Gateway Windows Service..." << std::endl;
    std::cout << "Service is running. Press Enter to exit." << std::endl;
    std::cin.get(); // Wait for user to press Enter

    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        std::cout << "Service is still running..." << std::endl;
    }
    service.stopService();
    std::cout << "Service stopped." << std::endl;
    return 0;
}
